## learn.py
## Author: Yangfeng Ji
## Date: 08-29-2014
## Time-stamp: <yangfeng 08/29/2014 23:37:49>

class Learn(object):
    def __init__(self):
        pass
